Projeto realizado por:
Evan Sá - 201707418
Diogo Ribeiro - 201703515

Descrição do programa:
	Este programa foi criado com o intuito de desenvolver um sistema de posts organizados por tópicos, este programa está dividido em duas partes, o lado do Cliente e o lado do Servidor. Cada utilizador pode no, programa Cliente, subscrever e publicar em vários tópicos e consultar o seu feed.

Funcionaliades do lado Cliente:
	Quando o programa é iniciado o utilizador é apresentado com o menu de login, tendo 3 opções: fazer login, criar um nova conta e sair do programa. Quando o utilizador cria uma nova conta, tem de esperar que um administrador a aprove, podendo fazer login apenas quando a sua conta foi aprovada. Após o login o utilizador é apresentado com o menu principal, onde se encontram a maior parte das funcionalidades do programa Cliente, sendo estas:
	-Ver o feed
	-Ver tópicos
	-Procurar tópicos mais activos
	-Subscrever um tópico
	-Publicar num tópico
	-Gerir lista de subscrições
	-Ver estatísticas
	-Alterar palavra passe

Descrição das funcionalidades do lado Cliente:
	O utilizador, através do programa Cliente, pode subscrever, ver e publicar num tópico. Pode também ver lista com alguns dos tópicos mais activos, com as suas subscrições ou sobre as estatísticas dos tópicos.
	-Ver feed: Aqui o utilizador é apresentado com todos os comentários dos tópicos a que se encontra subscrito.
	-Ver tópico: É apresentado ao utilizador todos os comentários de um tópico, tendo este a possibilidade de adicionar "like" a  um qualquer comentário.
	-Procurar tópicos mais activos: É apresentada uma lista com todos os tópicos que contém comentários e o devido número de comentários.
	-Subscrever tópicos: Aqui o utilizador pode adicionar um tópico à sua lista de subscrições.
	-Publicar num tópico: O utilizador pode adicionar um comentário a um tópico à sua escolha.
	-Gerir lista de subscrições: Aqui o utilizador pode vizualizar um lista com as suas subscrições e, se pretender, eliminar um ou mais tópicos dessa lista.
	-Ver estatísticas: Aqui o utilizador pode escolher entre ser apresentado com uma lista sobre: tópicos que contém comentários, tópicos com mais comentários, úmero de utilizadores que interagiram num respetivo tópico.
	-Alterar palavra passe: O utilizador pode alterar aqui a sua palavra passe.

Funcionalidades do lado Servidor:
	O programa Servidor foi criado com o intuito de ajudar a fazer a gestão dos utilizadores, e permite a que um admin tenho acesso a informação sobre estatísticas sobre atividade e popularidade de tópicos, podendo também criar e gerir tópicos. No menu do programa Servidor apresentam- se as seguintes opções:
	-Criar novo tópico
	-Remover utilizadores
	-Alterar username de um utilizador
	-Ver estatísticas
	-Validar utilizadores Cliente
	-Criar novos admins
	-Apagar admins
	-Alterar username de um admin

Descrição das funcionalidades do lado Servidor:
	-Criar novo tópico: A partir desta opção o admin pode criar novos tópicos, tendo de especificar informação adicional sobre esse tópico
	-Remover utilizadores: É apresentada uma lista de utilizadores onde o utilizador pode escolher um para eliminar
	-Alterar username de um utilizador: Aqui o amin pode escolher um utilizador Cliente a que pretende alterar o username
	-Ver estatísticas: É apresentado um menu onde o admin pode escolher várias opções para vizualizar estatísticas sobre tópicos
	-Validar utilizadores Cliente: O utilizador pode tornar contas de Clientes válidas através desta opçã
	-Criar novos admins: Aqui podem ser criadas novas contas admin
	-Apagar admins: Aqui podem ser eliminadas contas admin
	-Alterar username de um admin: Aqui podem ser alterados usernames de admins activos

Execução do programa:
	O Cliente, para executar o programa deve abrir um terminal na localização ~/LabC/project onde deverá compilar e executar o programa da seguinte maneira: javac loginCliente.java && java loginCliente
	Um Admin, para executar o programa deve abrir um terminal na localização ~/LabC/project onde deverá compilar e executar o programa da seguinte maneira: javac loginServer.java && java loginServer
