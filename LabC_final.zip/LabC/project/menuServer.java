import java.util.*;
import java.io.*;
import java.io.IOException;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Scanner;
import java.io.File;

public class menuServer {

// MENU ADMIN -----------------------------------------------------------
public static void menuAdmin() {

  Scanner stdin = new Scanner(System.in);

  System.out.println("* MENU ADMIN *");
  System.out.println("1. Criar novo tópico");
  System.out.println("2. Remover utilizadores");
  System.out.println("3. Alterar username de um utilizador");
  System.out.println("4. Ver estatísticas");
  System.out.println("5. Validar utilizadores");
  System.out.println("6. Criar novos utilizadores Admin");
  System.out.println("7. Apagar utilizadores Admin");
  System.out.println("8. Alterar username de um Admin");
  System.out.println("9. Logout");

  System.out.print("Escolha uma opção: "); int num = stdin.nextInt();
  System.out.println();


  while(num!=1 && num!=2 && num!=3 && num!=4 && num!=5 && num!=6 && num!=7 && num!=8 && num !=9) {
    System.out.print("Escolha errada, tente novamente: ");
    num = stdin.nextInt();
  }


 switch (num) {
    case 1: System.out.print("\033[H\033[2J");
            System.out.flush();
            novoTopico();
            break;
    case 2: System.out.print("\033[H\033[2J");
            System.out.flush();
            gerirUtlizadores();
            break;
    case 3: System.out.print("\033[H\033[2J");
            System.out.flush();
            editarUser();
            break;
    case 4: System.out.print("\033[H\033[2J");
            System.out.flush();
            estatisticas();
            break;
    case 5: System.out.print("\033[H\033[2J");
            System.out.flush();
            pendentes();
            break;
    case 6: System.out.print("\033[H\033[2J");
            System.out.flush();
            userServerRegistration();
            break;
    case 7: System.out.print("\033[H\033[2J");
            System.out.flush();
            apagarAdmins();
            break;
    case 8: System.out.print("\033[H\033[2J");
            System.out.flush();
            alterarAdmin();
            break;
    case 9: System.out.print("\033[H\033[2J");
            System.out.flush();
            loginServer texto = new loginServer(); //CHAMAR METODO no loginServer
            texto.menuLoginServer();

           }
         }






// VALIDAR USER ---------------------------------------------------------
public static void pendentes() {
  Scanner stdin = new Scanner(System.in);
  System.out.println("* PENDESTES *");
  // Leitura dos dados dos Utilizadores
  int cont=0; int j=3;
  int a = 0; // aceder à pass na string

  try {
    BufferedReader bf = new BufferedReader(new FileReader("../users/usersPendentes.txt"));
    BufferedReader separa = new BufferedReader(new FileReader("../users/usersPendentes.txt"));
    StringBuilder str = new StringBuilder();
    String linha = bf.readLine();


    while(linha != null) {
      str.append(linha); // verificar todos os utilizadores
      str.append(System.lineSeparator()); // seperador de linha
      linha = bf.readLine();
      cont++;
    }

  // Ler os user pendentes
  int b=1;
      String dados = str.toString();
      String[] separar = dados.split(" "); // separar os users e passwords

      // Print do Username no terminal
        for(int t=0; t < cont-1; t++) {
          System.out.println(b + ". " + separar[j]);
          b++;
          j=j+2;
        }

      int choice;
      System.out.println("\n0. Voltar atrás");
      System.out.print("Escolha quem quer aceitar: "); choice = stdin.nextInt();

      // Escolha errada
      while(choice >= cont || choice < 0) {
        System.out.print("Escolha errada, tente novamente: ");
        choice = stdin.nextInt();
      }

  //  ---------------------------- Aceitar users --------------------------------//
  // Passar de pendente para aceite
    if(choice > 0 && choice < cont) {
      try { // Passar de pendente para aceite
        BufferedReader br = new BufferedReader(new FileReader("../users/users.txt"));
        BufferedWriter escrever = new BufferedWriter(new FileWriter("../users/users.txt", true));

        escrever.write(" "); // da espaço
        escrever.write(separar[choice*2+1]); // username
        escrever.write(" ");
        escrever.write(separar[choice*2+2]); // password
        escrever.close();

  // -------------- Remover Pendente Aceite do ficheiro Pendente ---------------------- //
    String lineToRemove = separar[choice*2+1];
    BufferedReader file = new BufferedReader(new FileReader("../users/usersPendentes.txt"));
    String line;
    String input = "";

      while ((line = file.readLine()) != null) {
      //System.out.println(line);
        if(line.contains(lineToRemove)) {
          line = "";
      }
      input += line + '\n';
  }

    String input2 = input.replaceAll("(?m)^[ \t]*\r?\n", "");

    FileOutputStream File = new FileOutputStream("../users/usersPendentes.txt");
    File.write(input2.getBytes());
    file.close();
    File.close();
  // --------------------------------------------------------------------------------------

  }
  catch(Exception e)
  {
    System.out.println("Temos um Erro kk");
  }

  } else {
    System.out.println("Escolha errada, tente novamente: ");
  }

  // Voltar atŕas
  if(choice == 0) {
    System.out.print("\033[H\033[2J");
    System.out.flush();
    menuAdmin(); // Voltar ao menu Admin */
  }



  System.out.print("\033[H\033[2J");
  System.out.flush();
  pendentes(); // Voltar ao menu Admin */

    } catch (Exception e) {
      System.out.print("Erro kkk!");
    }
  }






// NOVO TÓPICO ----------------------------------------------------------
public static void novoTopico() {

  Scanner stdin = new Scanner(System.in);

  System.out.print("Introduzir nome do topico: ");
  String nometopico = stdin.nextLine();
  new File("../topicos/" + nometopico).mkdirs();


  // Crirar o ficheiro para os likes
  try
  {
    String a = "likes";
    File f = new File("../topicos/" + nometopico + "/" + a);
    f.mkdirs();

  }
  catch(Exception e)
  {
    System.out.println("Temos um Erro kk");
  }


  //String timestamp = new Timestamp(System.currentTimeMillis());
  SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	Date date = new Date();
	//System.out.println(dateFormat.format(date));



  try{
    BufferedWriter escrever = new BufferedWriter(new FileWriter("../topicos/" + nometopico + "/info" , true));
    escrever.write("Data de criação: ");
    escrever.write(dateFormat.format(date));
    escrever.newLine();

    escrever.write("Criado por: ");
    escrever.write(loginServer.userlogado);
    escrever.newLine();
    escrever.newLine();

    System.out.print("Indique a informação sobre o tópico: ");
    String info = stdin.nextLine();
    escrever.write("Informação sobre o tópico: ");
    escrever.write(info);
    escrever.newLine();

    escrever.flush();

  }
  catch(Exception e)
  {
    System.out.println("Temos um Erro kk");
  }


  System.out.print("\033[H\033[2J");
  System.out.flush();
  menuAdmin();

}






// REMOVER UTLIZADOR ----------------------------------------------------
public static void gerirUtlizadores() {
  Scanner stdin = new Scanner(System.in);

  System.out.println("* APAGAR UTILIZADORES *\n");
  int cont=0; int j=3;
  System.out.println("Utilizadores Ativos");
      try {
        BufferedReader bf = new BufferedReader(new FileReader("../users/users.txt"));
        BufferedReader separa = new BufferedReader(new FileReader("../users/users.txt"));
        StringBuilder str = new StringBuilder();
        String linha = bf.readLine();
        while(linha != null) {
          str.append(linha); // verificar todos os utilizadores
          str.append(System.lineSeparator()); // seperador de linha
          linha = bf.readLine();
          cont++;
        }

        // Ler os Utilizadors ativos
        int b=1;
            String dados = str.toString();
            String[] separar = dados.split(" "); // separar os users e passwords
            // Verificar se existe o Username
            for(int t=1; t<cont; t++) {
              System.out.println(b + ". " + separar[j]);
              b++;
              j=j+2;
            }

            System.out.println("\n0. Voltar atrás");
            int choice;
            System.out.print("\nRemover um utlizador: "); choice = stdin.nextInt();


            // Voltar atŕas
            if(choice == 0) {
              System.out.print("\033[H\033[2J");
              System.out.flush();
              menuAdmin();
            }


            // Escolha errada
            while(choice >= cont || choice <= 0) {
              System.out.print("Escolha errada, tente novamente: ");
              choice = stdin.nextInt();

              if(choice == 0) {
                System.out.print("\033[H\033[2J");
                System.out.flush();
                menuAdmin();
              }

            }

            choice += 1;

            // -------- Remover um Utilizador ------------ //
            if(choice-1>0 && choice-1<cont) {
              try
                {
                String lineToRemove = separar[choice*2-1];
                BufferedReader file = new BufferedReader(new FileReader("../users/users.txt"));
                String line;
                String input = "";
                  while ((line = file.readLine()) != null){

                      if(line.contains(lineToRemove)) {
                          line = "";
                      }
                      input += line + '\n';
                  }
                  String input2 = input.replaceAll("(?m)^[ \t]*\r?\n", "");

                  FileOutputStream File = new FileOutputStream("../users/users.txt");
                  File.write(input2.getBytes());
                  file.close();
                  File.close();

            }

            catch(Exception e)
            {
              System.out.println("Temos um Erro kk");
            }
              }


            // atualizar este metodo
            System.out.print("\033[H\033[2J");
            System.out.flush();
            gerirUtlizadores ();

      } catch (Exception e) {
        System.out.print("Erro kkk!");
      }

  }






// ALTERAR NOME DO UTULIZADOR  ------------------------------------------
public static void editarUser() {
  Scanner stdin = new Scanner(System.in);

  System.out.println("* EDITAR UTILIZADORES *\n");
  int cont=0; int j=3;
  System.out.println("Utilizadores Ativos");


  try {
    BufferedReader bf = new BufferedReader(new FileReader("../users/users.txt"));
    BufferedReader separa = new BufferedReader(new FileReader("../users/users.txt"));
    StringBuilder str = new StringBuilder();
    String linha = bf.readLine();

      while(linha != null) {
        str.append(linha); // verificar todos os utilizadores
        str.append(System.lineSeparator()); // seperador de linha
        linha = bf.readLine();
        cont++;
      }

    // Ler os Utilizadors ativos
        int b=1;
        String dados = str.toString();
        String[] separar = dados.split(" "); // separar os users e passwords

        // Verificar se existe o Username
          for(int t=1; t<cont; t++) {
            System.out.println(b + ". " + separar[j]);
            b++;
            j=j+2;
          }

        System.out.println("\n0. Voltar atrás");
        int choice;
        System.out.print("\nEscolha um utilizador: "); choice = stdin.nextInt();

        // Voltar atŕas
        if(choice == 0) {
          System.out.print("\033[H\033[2J");
          System.out.flush();
          menuAdmin();
        }


        // Escolha errada
        while(choice >= cont || choice < 0) {
          System.out.print("Escolha errada, tente novamente: ");
          choice = stdin.nextInt();

        }

          if(choice == 0) {
            System.out.print("\033[H\033[2J");
            System.out.flush();
            menuAdmin();
          }



        choice += 1;

          // -------- Mudar nome do Utilizador ------------ //
          if(choice-1 < cont) {

            String palavraNova;
            System.out.print("Novo nome a dar ao username: "); palavraNova = stdin.next();
            palavraNova = " " + palavraNova + " " + separar[choice*2];

            try
              {
              String lineToRemove = separar[choice*2-1];
              BufferedReader file = new BufferedReader(new FileReader("../users/users.txt"));
              String line;
              String input = "";
                while ((line = file.readLine()) != null){

                    if(line.contains(lineToRemove)) {
                        line = "";
                    }
                    input += line + '\n';
                }
                String input2 = input.replaceAll("(?m)^[ \t]*\r?\n", palavraNova);

                FileOutputStream File = new FileOutputStream("../users/users.txt");
                File.write(input2.getBytes());
                file.close();
                File.close();
          // -----------------------------------------
          }
          catch(Exception e)
          {
            System.out.println("Temos um Erro kk");
          }
        }

        // Voltar atŕas
        if(choice-1 == 0) {
          System.out.print("\033[H\033[2J");
          System.out.flush();
          menuAdmin(); // Voltar ao menu Admin */
        }

        // atualizar este metodo
        System.out.print("\033[H\033[2J");
        System.out.flush();
        editarUser(); // Voltar ao menu Admin */

  } catch (Exception e) {
    System.out.print("Erro kkk!");
  }

}






// CRIAR NOVO ADMIN -----------------------------------------------------
public static void userServerRegistration() {
    Scanner stdin = new Scanner(System.in);

    System.out.println("*Registro de um novo Admin*");

    // Username and Password
    String user, pass;
    System.out.print("Escolha um username: ");  // Username
    user = stdin.nextLine();
    System.out.print("Escolha uma password: "); // Password
    pass = stdin.nextLine();

    // Leitura dos dados dos Utilizadores
    int cont=0; int j=1; int bool=2;

    try {
      BufferedReader bf = new BufferedReader(new FileReader("../users/usersServer.txt"));
      BufferedReader separa = new BufferedReader(new FileReader("../users/usersServer.txt"));

      StringBuilder str = new StringBuilder();
      String linha = bf.readLine();

      while(linha != null) {
        str.append(linha); // verificar todos os utilizadores
        str.append(System.lineSeparator()); // seperador de linha
        linha = bf.readLine();
        cont++;
      }

      String dados = str.toString();
      String[] separar = dados.split(" "); // separar os users

      // Veirificar se existe ou nao um certo Username
      for(int t=0; t<cont; t++) {
        if(user.equals(separar[j])) { // Existe esse Username
          bool = 0;
          break;
        }else { // Não existe esse Username
          bool = 1;
        }
        j=j+2;
      }

    } catch (Exception e) { // verificar os erros
      System.out.println("Erro kkk!");
    }

    int escolha = 0;

    // Verificar se o username/password existe
    if(bool == 0) {
    System.out.println("Atenção! :: Username já existe.");

    System.out.print("\n1. Tentar novamente \n2. Voltar atrás\nEscolha: ");
    escolha = stdin.nextInt();

    // Escolha errada
    while(escolha > 2 || escolha <= 0) {
      System.out.print("Escolha errada, tente novamente: ");
      escolha = stdin.nextInt();
      }

      if(escolha == 1) {
      System.out.print("\033[H\033[2J");
      System.out.flush();
      userServerRegistration();
    }

      if(escolha == 2) {
        System.out.print("\033[H\033[2J");
        System.out.flush();
        menuAdmin();
      }
    }

      // Put information of the user in a file
      if(bool == 1) {
        try
        {
          BufferedWriter escrever = new BufferedWriter(new FileWriter("../users/usersServer.txt", true));
          escrever.write(" "); // da espaço
          escrever.write(user); // escreve o nome o username
          escrever.write(" "); // da espaço
          escrever.write(pass); // escreve a password
          escrever.newLine(); // vai para a linha seguinte
          escrever.close();
        }
        catch(Exception e)
        {
          System.out.println("Temos um Erro kk");
        }

        System.out.print("\033[H\033[2J");
        System.out.flush();
        menuAdmin();
      }
    }






// ESTATISTICAS ---------------------------------------------------------
public static void estatisticas(){

  Scanner stdin = new Scanner(System.in);

    System.out.println("* ESTATÍSTICAS *");

    System.out.println("1. Quantidade de tópicos ativos");
    System.out.println("2. Tópicos mais utilizados");
    System.out.println("3. Quantidade de comentários de um determinado tópico");
    System.out.println("4. Número de utilizadores diferentes que interagiram num tópico");
    System.out.println("5. Tópicos subscritos por um determinado utilizador");
    System.out.println("\n0. Voltar atrás");

    System.out.print("Escolha uma opção: "); int num = stdin.nextInt();


    while(num < 0 || num > 5) {
      System.out.print("Escolha errada, tente novamente: ");
      num = stdin.nextInt();
    }

    if(num == 0) {
      System.out.print("\033[H\033[2J");
      System.out.flush();
      menuAdmin();
    }

    switch (num) {
       case 1: System.out.print("\033[H\033[2J");
               System.out.flush();
               topicosAtivos();
               break;
       case 2: System.out.print("\033[H\033[2J");
               System.out.flush();
               topicosMaisUtilizados();
               break;
       case 3: System.out.print("\033[H\033[2J");
               System.out.flush();
               quantidadeComentarios();
               break;
       case 4: System.out.print("\033[H\033[2J");
               System.out.flush();
               quantidadeXusers();
               break;
       case 5: System.out.print("\033[H\033[2J");
               System.out.flush();
               listarUserSubs();
               break;

              }
  }






// Nº DE TOPICOS ATIVOS -------------------------------------------------
public static void topicosAtivos() {

    Scanner stdin = new Scanner(System.in);

    System.out.println("* TÓPICOS ATIVOS *");

    //guardar nomes dos topicos no array parentdir
    File parentfile = new File("../topicos");
    String[] parentdir = parentfile.list(new FilenameFilter() {
      @Override
      public boolean accept(File current, String name) {
        return new File(current, name).isDirectory();
      }
    });


    //preencher o array nuncomment
    for(int i=0; i<parentdir.length; i++){
      //preencher o array comment com o nome dos comentarios
      File file = new File("../topicos/" + parentdir[i]);
      String[] comment = file.list(new FilenameFilter() {
        @Override
        public boolean accept(File current, String name) {
          return new File(current, name).isFile();
        }
      });

    }



    System.out.println("Existem " + parentdir.length + " tópicos ativos, dos quais:");



      for(int i=0; i<parentdir.length; i++) {
        System.out.println("- " + parentdir[i]);
      }

      System.out.println();
      System.out.println("0. Voltar atrás");

      System.out.print("Escolha uma opção: ");

      int escolha = stdin.nextInt();

      // Escolha errada
      while(escolha != 0) {
        System.out.print("Escolha errada, tente novamente: ");
        escolha = stdin.nextInt();

      }

      if(escolha == 0){
        System.out.print("\033[H\033[2J");
        System.out.flush();
        estatisticas();
      }


    }






// TÓPICOS MAIS UTILIZADOS ----------------------------------------------
public static void topicosMaisUtilizados() {

    Scanner stdin = new Scanner(System.in);

  //  System.out.println("* TÓPICOS MAIS UTILIZADOS *");

    //guardar nomes dos topicos no array parentdir
    File parentfile = new File("../topicos");
    String[] parentdir = parentfile.list(new FilenameFilter() {
      @Override
      public boolean accept(File current, String name) {
        return new File(current, name).isDirectory();
      }
    });

    //criar array numcomment que contem o numero de comentarios
    //de cada topico
    int[] numcomment = new int[parentdir.length];

    //preencher o array nuncomment
    for(int i=0; i<parentdir.length; i++){
      //preencher o array comment com o nome dos comentarios
      File file = new File("../topicos/" + parentdir[i]);
      String[] comment = file.list(new FilenameFilter() {
        @Override
        public boolean accept(File current, String name) {
          return new File(current, name).isFile();
        }
      });

      //guardar o numero de comentarios de cada topico
      //no array numcomment
      int numdirs = comment.length;
      numcomment[i] = numdirs-1;
    }

      System.out.println("Tópico(s) mais utilizado(s): ");

  // Só os topicos com >= 3 comentarios é que sao os mais utilizados
      for(int i=0; i<parentdir.length; i++){
        if(numcomment[i] >= 3)
          System.out.println("- " + parentdir[i] + " (" + numcomment[i] + " comentários)");
        }


    System.out.println();
    System.out.println("0. Voltar atrás");

    System.out.print("Escolha uma opção: ");

    int escolha = stdin.nextInt();

    // Escolha errada
    while(escolha != 0) {
      System.out.print("Escolha errada, tente novamente: ");
      escolha = stdin.nextInt();

    }

    if(escolha == 0){
      System.out.print("\033[H\033[2J");
      System.out.flush();
      estatisticas();
    }


  }






// QUANTIDADE DE COMENTARIOS --------------------------------------------
public static void quantidadeComentarios() {

    Scanner stdin = new Scanner(System.in);

    System.out.println("* NÚMERO DE COMENTÁRIOS *");

    //guardar nomes dos topicos no array parentdir
    File parentfile = new File("../topicos");
    String[] parentdir = parentfile.list(new FilenameFilter() {
      @Override
      public boolean accept(File current, String name) {
        return new File(current, name).isDirectory();
      }
    });

    //criar array numcomment que contem o numero de comentarios
    //de cada topico
    int[] numcomment = new int[parentdir.length];

    //preencher o array nuncomment
    for(int i=0; i<parentdir.length; i++){
      //preencher o array comment com o nome dos comentarios
      File file = new File("../topicos/" + parentdir[i]);
      String[] comment = file.list(new FilenameFilter() {
        @Override
        public boolean accept(File current, String name) {
          return new File(current, name).isFile();
        }
      });

      //guardar o numero de comentarios de cada topico
      //no array numcomment
      int numdirs = comment.length;
      numcomment[i] = numdirs-1;
    }


  // Todos os topicos e o nº dos seus comentários
      for(int i=0; i<parentdir.length; i++){

          System.out.println("- O tópico *" + parentdir[i] + "* tem " + numcomment[i] + " comentário(s)");
        }


    System.out.println();
    System.out.println("0. Voltar atrás");

    System.out.print("Escolha uma opção: ");

    int escolha = stdin.nextInt();

    // Escolha errada
    while(escolha != 0) {
      System.out.print("Escolha errada, tente novamente: ");
      escolha = stdin.nextInt();
    }

    if(escolha == 0){
      System.out.print("\033[H\033[2J");
      System.out.flush();
      estatisticas();
    }
  }






// LISTAR SUBS ----------------------------------------------------------
public static void listarUserSubs() {

  Scanner stdin = new Scanner(System.in);

  System.out.println("* TÓPICOS SUBSCRITOS *");

  System.out.println("Utilizadores com subscrições: ");

  //guardar os comentarios .txt em comments[]
  File f2 = new File("../users/subs");
  String[] comments = f2.list(new FilenameFilter() {
    @Override
    public boolean accept(File current, String name) {
      return new File(current, name).isFile();
  }
  });
  int b=1;
  for(int i=0; i<comments.length; i++) {
    System.out.println(b + ". " + comments[i]);
    b++;
  }

  System.out.println("\n0. Voltar atrás");

  //pedir input de escolha
  System.out.print("Escolha uma opção: ");
  int escolha = stdin.nextInt();


  // Escolha errada
  while(escolha < 0 || escolha > b-1) {
    System.out.print("Escolha errada, tente novamente: ");
    escolha = stdin.nextInt();
  }

  if(escolha == 0){
    System.out.print("\033[H\033[2J");
    System.out.flush();
    estatisticas();
  }

  if(escolha > 0 && escolha <= comments.length){
    System.out.print("\033[H\033[2J");
    System.out.flush();
    String name = comments[escolha-1];
    listaSubs(name);
  }




}






// QUANTIDADE DE USERS POR TOPICO ---------------------------------------
public static void quantidadeXusers() {

    Scanner stdin = new Scanner(System.in);

    System.out.println("* NÚMERO DE UTILIZADORES QUE INTERAGIRAM NUM TÓPICO *");

    //guardar nomes dos topicos no array parentdir
    File parentfile = new File("../topicos");
    String[] parentdir = parentfile.list(new FilenameFilter() {
      @Override
      public boolean accept(File current, String name) {
        return new File(current, name).isDirectory();
      }
    });

    //criar array numcomment que contem o numero de comentarios
    //de cada topico
    int[] numcomment = new int[parentdir.length];

    //preencher o array nuncomment
    for(int i=0; i<parentdir.length; i++){
      //preencher o array comment com o nome dos comentarios
      File file = new File("../topicos/" + parentdir[i]);
      String[] comment = file.list(new FilenameFilter() {
        @Override
        public boolean accept(File current, String name) {
          return new File(current, name).isFile();
        }
      });

      //guardar o numero de comentarios de cada topico
      //no array numcomment
      int numdirs = comment.length;
      numcomment[i] = numdirs-1;
    }

      int b=1;
      // Todos os topicos e o nº dos seus comentários
        for(int i=0; i<parentdir.length; i++){
            System.out.println(b + ". " + parentdir[i]);
            b++;
          }



        System.out.println();
        System.out.println("0. Voltar atrás");

        System.out.print("Escolha uma opção: ");

        int escolha = stdin.nextInt();

        int cont = 0;

        if(escolha > 0 && escolha < b) {
        try {
          BufferedReader bf = new BufferedReader(new FileReader("../topicos/" + parentdir[escolha-1] + "/likes/xusers"));

          StringBuilder str = new StringBuilder();
          String linha = bf.readLine();

          while(linha != null) {
            str.append(linha); // verificar todos os utilizadores
            str.append(System.lineSeparator()); // seperador de linha
            linha = bf.readLine();
            cont++;
          }

          System.out.println("\nNo tópico *" + parentdir[escolha-1] + "* interagiram " + cont + " utilizador(s) diferente(s)\n");


        } catch (Exception e) { // verificar os erros
          System.out.println("Erro kkk!");
        }
            }




    // Escolha errada
    while(escolha < 0 || escolha >= b) {
      System.out.print("Escolha errada, tente novamente: ");
      escolha = stdin.nextInt();
    }

    if(escolha == 0){
      System.out.print("\033[H\033[2J");
      System.out.flush();
      estatisticas();
    }


    System.out.println("Deseja ver mais?");
    System.out.println(b + ".Sim  " + (b+1) + ".Não");
    System.out.print("Escolha uma opção: ");

    int choice = stdin.nextInt();

    if(choice == b) {
      System.out.print("\033[H\033[2J");
      System.out.flush();
      quantidadeXusers();
    }

    if(choice == b+1) {
      System.out.print("\033[H\033[2J");
      System.out.flush();
      estatisticas();

    }

  }






// LISTA DAS SUBSCRIÇÕES ------------------------------------------------
public static void listaSubs(String name) {

  Scanner stdin = new Scanner(System.in);

  System.out.println("O utilizador " + name + " tens as seguintes subscrições: ");

  try {
    BufferedReader in = new BufferedReader(new FileReader("../users/subs/" + name));

      String line;
    while((line = in.readLine()) != null)
    {
        System.out.println(line);
    }
    in.close();

  } catch (Exception e) { // verificar os erros
    System.out.println("Erro kkk!");
  }

    System.out.println("\n0. Voltar atrás");
    System.out.print("Escolha uma opção: ");

    int p = stdin.nextInt();

    if(p == 0) {
    System.out.print("\033[H\033[2J");
    System.out.flush();
    listarUserSubs();
    }

    while(p != 0) {
      System.out.print("Escolha errada, tente novamente: ");
      p = stdin.nextInt();
    }


  }






  // REMOVER UTLIZADOR ----------------------------------------------------
  public static void apagarAdmins() {
    Scanner stdin = new Scanner(System.in);

    System.out.println("* APAGAR ADMINS *\n");
    int cont=0; int j=1;
    System.out.println("Contas Admin");
        try {
          BufferedReader bf = new BufferedReader(new FileReader("../users/usersServer.txt"));
          BufferedReader separa = new BufferedReader(new FileReader("../users/usersServer.txt"));
          StringBuilder str = new StringBuilder();
          String linha = bf.readLine();
          while(linha != null) {
            str.append(linha); // verificar todos os utilizadores
            str.append(System.lineSeparator()); // seperador de linha
            linha = bf.readLine();
            cont++;
          }

          // Ler os Utilizadors ativos
          int b=1;
              String dados = str.toString();
              String[] separar = dados.split(" "); // separar os users e passwords
              // Verificar se existe o Username
              for(int t=1; t<=cont; t++) {
                System.out.println(b + ". " + separar[j]);
                b++;
                j=j+2;
              }

              System.out.println("\n0. Voltar atrás");
              int choice;
              System.out.print("\nRemover um admin: "); choice = stdin.nextInt();


              // Voltar atŕas
              if(choice == 0) {
                System.out.print("\033[H\033[2J");
                System.out.flush();
                menuAdmin();
              }


              // Escolha errada
              while(choice > cont || choice <= 0) {
                System.out.print("Escolha errada, tente novamente: ");
                choice = stdin.nextInt();

                if(choice == 0) {
                  System.out.print("\033[H\033[2J");
                  System.out.flush();
                  menuAdmin();
                }

              }



              // -------- Remover um Utilizador ------------ //
              if(choice>0 && choice<=cont) {
                try
                  {
                  String lineToRemove = separar[choice*2-1];
                  BufferedReader file = new BufferedReader(new FileReader("../users/usersServer.txt"));
                  String line;
                  String input = "";
                    while ((line = file.readLine()) != null){

                        if(line.contains(lineToRemove)) {
                            line = "";
                        }
                        input += line + '\n';
                    }
                    String input2 = input.replaceAll("(?m)^[ \t]*\r?\n", "");

                    FileOutputStream File = new FileOutputStream("../users/usersServer.txt");
                    File.write(input2.getBytes());
                    file.close();
                    File.close();

              }

              catch(Exception e)
              {
                System.out.println("Temos um Erro kk");
              }
                }


              // atualizar este metodo
              System.out.print("\033[H\033[2J");
              System.out.flush();
              apagarAdmins ();

        } catch (Exception e) {
          System.out.print("Erro kkk!");
        }

    }






    // ALTERAR NOME DO UTULIZADOR  ------------------------------------------





 // ALTERAR USERNAME ADMIN ----------------------------------------------
public static void alterarAdmin() {
      Scanner stdin = new Scanner(System.in);

      System.out.println("* EDITAR ADMINS *\n");
      int cont=0; int j=1;
      System.out.println("Contas Admins");


      try {
        BufferedReader bf = new BufferedReader(new FileReader("../users/usersServer.txt"));
        BufferedReader separa = new BufferedReader(new FileReader("../users/usersServer.txt"));
        StringBuilder str = new StringBuilder();
        String linha = bf.readLine();

          while(linha != null) {
            str.append(linha); // verificar todos os utilizadores
            str.append(System.lineSeparator()); // seperador de linha
            linha = bf.readLine();
            cont++;
          }

        // Ler os Utilizadors ativos
            int b=1;
            String dados = str.toString();
            String[] separar = dados.split(" "); // separar os users e passwords

            // Verificar se existe o Username
              for(int t=1; t<=cont; t++) {
                System.out.println(b + ". " + separar[j]);
                b++;
                j=j+2;
              }

            System.out.println("\n0. Voltar atrás");
            int choice;
            System.out.print("\nEscolha um utilizador: "); choice = stdin.nextInt();

            // Voltar atŕas
            if(choice == 0) {
              System.out.print("\033[H\033[2J");
              System.out.flush();
              menuAdmin();
            }


            // Escolha errada
            while(choice > cont || choice < 0) {
              System.out.print("Escolha errada, tente novamente: ");
              choice = stdin.nextInt();

            }

              if(choice == 0) {
                System.out.print("\033[H\033[2J");
                System.out.flush();
                menuAdmin();
              }




              // -------- Mudar nome do Utilizador ------------ //
              if(choice <= cont && choice > 0) {

                String palavraNova;
                System.out.print("Novo nome a dar ao username: "); palavraNova = stdin.next();
                palavraNova = " " + palavraNova + " " + separar[choice*2];

                try
                  {
                  String lineToRemove = separar[choice*2-1];
                  BufferedReader file = new BufferedReader(new FileReader("../users/usersServer.txt"));
                  String line;
                  String input = "";
                    while ((line = file.readLine()) != null){

                        if(line.contains(lineToRemove)) {
                            line = "";
                        }
                        input += line + '\n';
                    }
                    String input2 = input.replaceAll("(?m)^[ \t]*\r?\n", palavraNova);

                    FileOutputStream File = new FileOutputStream("../users/usersServer.txt");
                    File.write(input2.getBytes());
                    file.close();
                    File.close();
              // -----------------------------------------
              }
              catch(Exception e)
              {
                System.out.println("Temos um Erro kk");
              }
            }

            // Voltar atŕas
            if(choice == 0) {
              System.out.print("\033[H\033[2J");
              System.out.flush();
              menuAdmin(); // Voltar ao menu Admin */
            }

            // atualizar este metodo
            System.out.print("\033[H\033[2J");
            System.out.flush();
            alterarAdmin(); // Voltar ao menu Admin */

      } catch (Exception e) {
        System.out.print("Erro kkk!");
      }

    }




}
