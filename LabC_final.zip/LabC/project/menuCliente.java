import java.util.*;
import java.io.*;
import java.io.IOException;
import java.io.File;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Arrays;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Collections;

public class menuCliente {

// MENU CLIENTE ---------------------------------------------------------
public static void menu() {

  Scanner stdin = new Scanner(System.in);

  System.out.println("* MENU CLIENTE *");
  System.out.println("1. Ver feed");
  System.out.println("2. Ver tópicos");
  System.out.println("3. Procurar tópicos mais ativos");
  System.out.println("4. Subscrever tópico");
  System.out.println("5. Publicar num tópico");
  System.out.println("6. Gerir lista de subscrições");
  System.out.println("7. Ver estatísticas");
  System.out.println("8. Alterar palavra passe");
  System.out.println("9. Logout");

  System.out.print("Escolha uma opção: "); int num = stdin.nextInt();
  System.out.println();


  while(num!=1 && num!=2 && num!=3 && num!=4 && num!=5 && num!=6 && num!=7 && num!=8 && num !=9) {
    System.out.print("Escolha errada, tente novamente: ");
    num = stdin.nextInt();
  }

  // Escolha dos numeros
  switch (num) {
      case 1: System.out.print("\033[H\033[2J");
              System.out.flush();
              feed();
              break;
      case 2: System.out.print("\033[H\033[2J");
              System.out.flush();
              verTopico();
              break;
      case 3: System.out.print("\033[H\033[2J");
              System.out.flush();
              topicosactivos();
              break;
      case 4: System.out.print("\033[H\033[2J");
              System.out.flush();
              Subscrever();
              break;
      case 5: System.out.print("\033[H\033[2J");
              System.out.flush();
              publicar();
              break;
      case 6: System.out.print("\033[H\033[2J");
              System.out.flush();
              GerirSubs();
              break;
      case 7: System.out.print("\033[H\033[2J");
              System.out.flush();
              estatisticas();
              break;
      case 8: System.out.print("\033[H\033[2J");
              System.out.flush();
              verificarPass();
              break;
      case 9: System.out.print("\033[H\033[2J");
              System.out.flush();
              loginCliente texto = new loginCliente(); //CHAMAR METODO no loginServer
              texto.menuLoginCliente();
             }
           }






// VER FEED -------------------------------------------------------------
public static void feed() {

   Scanner stdin = new Scanner(System.in);

   System.out.println("Feed: ");
   System.out.println();

   String linha = null;
   int flag = 0;

   try {
     BufferedReader read = new BufferedReader(new FileReader("../users/subs/" + loginCliente.clientelogado) );
     //ler o ficheiro subs especifico ao cliente que esta logado
     //se a linha nao estiver vazia, imprime a para a consola
     while((linha = read.readLine()) != null) {

       File f2 = new File("../topicos/" + linha);
       String[] comments = f2.list(new FilenameFilter() {
         @Override
         public boolean accept(File current, String name) {
           return new File(current, name).isFile();
       }
       });

       //guardar numero de comentarios em numcomms
       int numcomms = comments.length;

       //guardar data de ultima modificacao dos comentarios no array ages[]
       long[] ages = new long[numcomms];
       for(int i=0; i<numcomms; i++){
         File indivcomment = new File("../topicos/" + linha + "/" + comments[i]);
         long age = indivcomment.lastModified();
         ages[i] = age;
       }

       // organiza o array ages de forma ascendente
       Arrays.sort(ages);
       System.out.println();

       //ciclos que comparam nomes de ficheiros com as datas organizadas do array ages
       //comparam indivcomment.lastModified com ages[]
       for(int i=0; i<numcomms; i++){
         for(int j=0; j<numcomms; j++){
           File indivcomment = new File("../topicos/" + linha + "/" + comments[j]);
           if(ages[i] == indivcomment.lastModified()){

             //le o ficheiro e imprime na consola
             try (BufferedReader br = new BufferedReader(new FileReader("../topicos/" + linha + "/" + comments[j]))) {
               String line = null;
               while ((line = br.readLine()) != null) {
                 System.out.println(line);
               }
               //em caso de erro imprime "erro"
             } catch (IOException e) {
       		      System.out.println("Erro");
               }
               //espacamento
               System.out.println();
               System.out.println();
               System.out.println("--------------------------------");
               System.out.println();
               System.out.println();
           }
         }
       }

     }
   } catch(Exception e) {
     System.out.println("Erro");
   }

   //voltar para menu inicial
   System.out.println("0. Voltar atrás");
   System.out.print("Escolha uma opção: ");

   int sair = stdin.nextInt();

   while(sair != 0) {
     System.out.print("Escolha errada, tente novamente: ");
     sair = stdin.nextInt();
   }

   if(sair == 0){
     System.out.print("\033[H\033[2J");
     System.out.flush();
     menu();
   }

  }


// VER TÓPICOS ----------------------------------------------------------
public static void verTopico() {
    Scanner stdin = new Scanner(System.in);

    System.out.println("*TÓPICOS*");

    //nome das folders colocados em directories
    File file = new File("../topicos");
    String[] directories = file.list(new FilenameFilter() {
      @Override
      public boolean accept(File current, String name) {
        return new File(current, name).isDirectory();
      }
    });

    int c=1;
    //numerar folders a partir de directories[]
    int numdirs = directories.length;
    for(int i=0; i<numdirs; i++){
      System.out.println(c + ". " + directories[i]);
      c++;
    }

    System.out.println("\n0. Voltar atrás");


    System.out.print  ("Escolha uma opção: ");

    int escolha = stdin.nextInt();

    if(escolha == 0){
      System.out.print("\033[H\033[2J");
      System.out.flush();
      menu();
    }

    while(escolha < 0 || escolha > numdirs) {
      System.out.print("Escolha errada, tente novamente: ");
      escolha = stdin.nextInt();
    }

    escolha -= 1;

    //guardar os comentarios .txt em comments[]
    File f2 = new File("../topicos/" + directories[escolha]);
    String[] comments = f2.list(new FilenameFilter() {
      @Override
      public boolean accept(File current, String name) {
        return new File(current, name).isFile();
    }
    });

    //guardar numero de comentarios em numcomms
    int numcomms = comments.length;


    //guardar data de ultima modificacao dos comentarios no array ages[]
    long[] ages = new long[numcomms];
    for(int i=0; i<numcomms; i++){
      File indivcomment = new File("../topicos/" + directories[escolha] + "/" + comments[i]);
      long age = indivcomment.lastModified();
      ages[i] = age;
    }

    // organiza o array ages de forma ascendente
    Arrays.sort(ages);
    System.out.println();



    //ciclos que comparam nomes de ficheiros com as datas organizadas do array ages
    //comparam indivcomment.lastModified com ages[]
    int k=2;
    int g=numcomms+1;
    int r=1;
    for(int i=0; i<numcomms; i++) {
      for(int j=0; j<numcomms; j++) {

        File indivcomment = new File("../topicos/" + directories[escolha] + "/" + comments[j]);
        if(ages[i] == indivcomment.lastModified()){

          // Dar split aos likes **
        try {
          int cont=0;
          BufferedReader bf = new BufferedReader(new FileReader("../topicos/" + directories[escolha] + "/likes/likes"));
          BufferedReader separa = new BufferedReader(new FileReader("../topicos/" + directories[escolha] + "/likes/likes"));
          StringBuilder str = new StringBuilder();

          String linha = bf.readLine();

          while(linha != null) {
            str.append(linha); // verificar todos os utilizadores
            str.append(System.lineSeparator()); // seperador de linha
            linha = bf.readLine();
            cont++;
          }

          // Separar os likes **
          String dados = str.toString();
          String[] separar = dados.split(" "); // separar os users e passwords

          //le o ficheiro e imprime na consola
          try (BufferedReader br = new BufferedReader(new FileReader("../topicos/" + directories[escolha] + "/" + comments[j]))) {
            String line = null;


            while ((line = br.readLine()) != null) {
              System.out.println(line);

            }

            // Acrescimo para os likes **
            if(g<numcomms+1) {
            System.out.print("\nO número de likes é igual a: ");
            System.out.println(separar[k]);
            System.out.println(r + ". Dar like ao comentário");
            k+=3;
            r++;
          }
          g--;


            //em caso de erro imprime "erro"
          } catch (IOException e) {
    		      System.out.println("Erro");
            }


          } catch (Exception e) {
            System.out.print("Erro kkk!");
          }

            //espacamento
            System.out.println();
            System.out.println();
            System.out.println("--------------------------------");
            System.out.println();
            System.out.println();
        }
      }
    }

    //Sair ou voltar ao menu principal
    System.out.println(r + ". Ver mais tópicos");
    System.out.println("0. Voltar atrás");
    System.out.print("Escolha uma opção: ");
    int m = stdin.nextInt();
    if(m == 0){
      System.out.print("\033[H\033[2J");
      System.out.flush();
      menu();
    }

    if(m>0 && m<=r) {
      String dir = directories[escolha];
      alterarLikes(dir,m);
    }

    if(m == r) {
      System.out.print("\033[H\033[2J");
      System.out.flush();
      verTopico();
    }



  }


  // ALTERAR LIKES ---------------------------------------------------------------------------
  public static void alterarLikes(String diretorio, int numPost) {

    Scanner stdin = new Scanner(System.in);


    int cont=0; int j=3;


    try {
      BufferedReader bf = new BufferedReader(new FileReader("../topicos/" + diretorio + "/likes/likes"));
      StringBuilder str = new StringBuilder();
      BufferedReader separa = new BufferedReader(new FileReader("../topicos/" + diretorio + "/likes/likes"));
      String linha = bf.readLine();

        while(linha != null) {
          str.append(linha); // verificar todos os utilizadores
          str.append(System.lineSeparator()); // seperador de linha
          linha = bf.readLine();
          cont++;
        }

        // Separar os likes **
        String dados = str.toString();
        String[] separar = dados.split(" "); // separar os users e passwords





              String novaPass;
              String like = separar[numPost*3-1];


              // Aumentar o like e converter para int
              int number = Integer.parseInt(like);
              number++;


              // converter para String
              String s = String.valueOf(number);



              novaPass = " " + separar[numPost*3-2] + " " + s + " " + "Likes" + "\n";

              try
                {
                String lineToRemove = separar[numPost*3-2];
                BufferedReader file = new BufferedReader(new FileReader("../topicos/" + diretorio + "/likes/likes"));
                String line;
                String input = "";
                  while ((line = file.readLine()) != null){

                      if(line.contains(lineToRemove)) {
                          line = "";
                      }
                      input += line + '\n';
                  }
                  String input2 = input.replaceAll("(?m)^[ \t]*\r?\n", novaPass);

                  FileOutputStream File = new FileOutputStream("../topicos/" + diretorio + "/likes/likes");
                  File.write(input2.getBytes());
                  file.close();
                  File.close();
            // -----------------------------------------
            }
            catch(Exception e)
            {
              System.out.println("Temos um Erro kk");
            }




          // atualizar este metodo
          System.out.print("\033[H\033[2J");
          System.out.flush();
          verTopico(); // Voltar ao menu Admin */

    } catch (Exception e) {
      System.out.print("Erro kkk!");
    }




  }






// PUBLICAR EM TOPICO ---------------------------------------------------
public static void publicar() {

  Scanner stdin = new Scanner(System.in);

  System.out.println("Escolha o tópico em que pretende publicar: \n");

  //listar nome das folders
  File file = new File("../topicos");
  String[] directories = file.list(new FilenameFilter() {
    @Override
    public boolean accept(File current, String name) {
      return new File(current, name).isDirectory();
    }
  });

  //numerar folders
  int numdirs = directories.length;
  for(int i=0; i<numdirs; i++){
    System.out.println(i+1 + ". " + directories[i]);
  }

  System.out.println("\n0. Voltar atrás");


  System.out.print  ("Escolha uma opção: ");

  int escolha = stdin.nextInt();


  if(escolha == 0){
    System.out.print("\033[H\033[2J");
    System.out.flush();
    menu();
  }

  while(escolha < 0 || escolha > numdirs) {
    System.out.print("Escolha errada, tente novamente: ");
    escolha = stdin.nextInt();
  }


  escolha -= 1;



  //datas para formatar
  SimpleDateFormat dateFormat2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
  SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");
	Date date = new Date();

  String filename = dateFormat.format(date);
  String data2 = dateFormat2.format(date);


  // --------------------------------------
  // Verificar se ja existe algum user a participar naquele topico
    String name = loginCliente.clientelogado;
    int flag=0;
    try {
      String lineToRemove = name;
      BufferedReader file2 = new BufferedReader(new FileReader("../topicos/" + directories[escolha] + "/likes/xusers"));
      String line;
      String input = "";
        while ((line = file2.readLine()) != null){

            if(line.contains(lineToRemove)) {
                flag = 1;
            }
        }
  }
  catch(Exception e) {
    System.out.print("");
  }


  // Se o user nunca falou num topico x, é guardado o seu nome no ficheiro xusers
  try {

    if(flag == 0) {
      //criar ficheiro de texto para o comentario e escrever o comentario
       File newfile = new File("../topicos/" + directories[escolha] + "/likes/xusers");
       BufferedWriter escrever2 = new BufferedWriter(new FileWriter("../topicos/" + directories[escolha] + "/likes/xusers", true));
       escrever2.write(loginCliente.clientelogado);
       escrever2.newLine();
       escrever2.close();
     }

  } catch (IOException e) {
       System.out.print("");
    }

    // --------------------------------------

    try {
        //criar ficheiro de texto para o comentario e escrever o comentario
	       File newfile = new File("../topicos/" + directories[escolha] + "/" + filename );

         System.out.println();
         System.out.print("Insira o que quer comentar no tópico: ");
         stdin.nextLine();
         String comentario = stdin.nextLine();
         BufferedWriter escrever = new BufferedWriter(new FileWriter("../topicos/" + directories[escolha] + "/" + filename , true));
         escrever.write("Comentário criado por: " + loginCliente.clientelogado + " em " + data2);
         escrever.newLine();
         escrever.newLine();
         escrever.write(comentario);
         escrever.close();



         // Chamar o metodo para colocar o nome do post, para os LIKES
         String likes = "0"; // 0 likes inicialmente
         String topico = directories[escolha];
         putNameLikes(filename,likes,topico);


         System.out.print("\033[H\033[2J");
         System.out.flush();
         menu();

    } catch (IOException e) {
    		 System.out.println("Erro");
    }




 }






// METER O NOME DO TOPICO NO FICHEIRO LIKES -----------------------------
  public static void putNameLikes(String postName, String likes, String topico) {

    try
    {
      BufferedWriter escrever = new BufferedWriter(new FileWriter("../topicos/" + topico + "/likes/likes", true));
      escrever.write(" "); // da espaço
      escrever.write(postName); // escreve o nome o username
      escrever.write(" "); // da espaço
      escrever.write(likes); // escreve a password
      escrever.write(" "); // da espaço
      escrever.write("Likes");
      escrever.newLine(); // vai para a linha seguinte
      escrever.close();
    }
    catch(Exception e)
    {
      System.out.println("Temos um Erro kk");
    }

  }






// SUBESCREVER ----------------------------------------------------------
 public static void Subscrever() {

   Scanner stdin = new Scanner(System.in);

   System.out.println("Tópicos que pode subscrever: ");

   //listar nome das folders
   File file = new File("../topicos");
   String[] directories = file.list(new FilenameFilter() {
     @Override
     public boolean accept(File current, String name) {
       return new File(current, name).isDirectory();
     }
   });

   //numerar folders
   int numdirs = directories.length;

   for(int i=0; i<numdirs; i++){
     System.out.println(i+1 + ". " + directories[i]);
   }

   System.out.println("\n0. Voltar atrás");

   System.out.print("Escolha o tópico a que pretende subscrever: ");

   int escolha = stdin.nextInt();

   int flag = 0;

   // Escolha errada
   while(escolha < 0 || escolha > numdirs) {
     System.out.print("Escolha errada, tente novamente: ");
     escolha = stdin.nextInt();
     }

     //Sair
     if(escolha == 0){
       System.out.print("\033[H\033[2J");
       System.out.flush();
       menu();
     }

   if(escolha > 0 && escolha <= numdirs) {

   try{
        BufferedReader loc = new BufferedReader(new FileReader("../users/subs/" + loginCliente.clientelogado));
        String linha = loc.readLine();

        while(linha != null){
          if(directories[escolha-1].equals(linha)){
            System.out.println();
            System.out.println("Já se encontra subscrito a este tópico!\n");
            flag=1;
            break;
          }
          linha = loc.readLine();
        }
   } catch (IOException e) {
        System.out.print("");
   }

   if(flag == 0) {
     try {
       System.out.println("\nTópico subscrito com sucesso!\n");
        //alterar ficheiro de texto das subs para incluir o topico escolhido
        BufferedWriter escrever = new BufferedWriter(new FileWriter("../users/subs/" + loginCliente.clientelogado, true));
        escrever.write(directories[escolha-1]);
        escrever.newLine();
        escrever.close();

        } catch (IOException e) {
          System.out.print("");
        }
    }

  }

      int p;
     //Sair ou subscrever mais topicos
     System.out.println("1. Subscrever mais tópicos");
     System.out.println("2. Voltar atŕas");
     System.out.print("Escolha uma opção:");

     p = stdin.nextInt();

     // Escolha errada
     while(p!=1 && p!=2) {
       System.out.print("Escolha errada, tente novamente: ");
       p = stdin.nextInt();
       }

     if(p == 1) {
       System.out.print("\033[H\033[2J");
       System.out.flush();
       Subscrever();
     }

     if(p == 2) {
       System.out.print("\033[H\033[2J");
       System.out.flush();
       menu();
     }

   }






// GERIR SUBS -----------------------------------------------------------
 public static void GerirSubs() {

   Scanner stdin = new Scanner(System.in);

   System.out.println("* MENU DE GESTÃO DE SUBSCRIÇÕES *");
   System.out.println();
   System.out.println("1. Ver tópicos subscritos");
   System.out.println("2. Eliminar subscrição");
   System.out.println("\n0. Voltar atrás");
   System.out.print("Escolha uma opção: ");

   int escolha = stdin.nextInt();

   while(escolha != 1 && escolha !=2 && escolha != 0){
     System.out.print("Escolha inválida, tente novamente: ");
     escolha = stdin.nextInt();
     }


   if(escolha == 0) {
     System.out.print("\033[H\033[2J");
     System.out.flush();
     menu();
   }


   switch(escolha) {
     case 1: System.out.print("\033[H\033[2J");
             System.out.flush();
             VerSubs();

     case 2: System.out.print("\033[H\033[2J");
             System.out.flush();
             ElimSubs();
  }

 }






// VER SUBS -------------------------------------------------------------
 public static void VerSubs() {

   Scanner stdin = new Scanner(System.in);

   System.out.println("Subscrições activas: ");
   System.out.println();

   String linha = null;
   int flag = 0;

   try {
     BufferedReader read = new BufferedReader(new FileReader("../users/subs/" + loginCliente.clientelogado) );
     //ler o ficheiro subs especifico ao cliente que esta logado
     //se a linha nao estiver vazia, imprime a para a consola
     while((linha = read.readLine()) != null) {
       System.out.println(linha);
       flag++;
     }
   } catch(Exception e) {
     System.out.println("Erro");
   }

   System.out.println("\n0. Voltar atrás");

   System.out.print("Escolha uma opção: ");

   int escolha = stdin.nextInt();

   // Escolha errada
   while(escolha != 0) {
     System.out.print("Escolha errada, tente novamente: ");
     escolha = stdin.nextInt();

   }

   if(escolha == 0){
     System.out.print("\033[H\033[2J");
     System.out.flush();
     GerirSubs();
   }


 }






// ELIMINAR SUBS --------------------------------------------------------
 public static void ElimSubs() {

  Scanner stdin = new Scanner(System.in);

  System.out.println("Escolha o tópico que pretende eliminar: ");
  System.out.println();

  String linha = null;
  int flag = 0;

  try {
    BufferedReader read = new BufferedReader(new FileReader("../users/subs/" + loginCliente.clientelogado) );
    //ler o ficheiro subs especifico ao cliente que esta logado
    //se a linha nao estiver vazia, imprime a para a consola
    while((linha = read.readLine()) != null) {
      System.out.println(flag+1  + ". " + linha);
      flag++;
    }
  } catch(Exception e) {
    System.out.println("Erro");
  }

  System.out.println("\n0. Voltar atrás");

  System.out.print("Escolha uma opção: ");

  int escolha = stdin.nextInt();

  // Escolha errada
  while(escolha < 0 || escolha > flag) {
    System.out.print("Escolha errada, tente novamente: ");
    escolha = stdin.nextInt();
  }

  if(escolha == 0){
    System.out.print("\033[H\033[2J");
    System.out.flush();
    GerirSubs();
  }

  escolha -= 1;

  //criacao de string
  String linhaescolhida = null;

  //string "linhaescolhida" tem os conteudos iguais ao topico que
  //o utilizador escolheu
  try {
    BufferedReader read = new BufferedReader(new FileReader("../users/subs/" + loginCliente.clientelogado) );
    for(int i=0; i<=escolha; i++){
        linhaescolhida = read.readLine();
    }
  } catch(Exception e) {
    System.out.println("Erro");
  }

  //le a linha escolhida e remove essa linha
  try
    {
    String lineToRemove = linhaescolhida;
    BufferedReader file = new BufferedReader(new FileReader("../users/subs/" + loginCliente.clientelogado));
    String line;
    String input = "";
      while ((line = file.readLine()) != null){

          if(line.contains(lineToRemove)) {
              line = "";
          }
          input += line + '\n';
      }
      String input2 = input.replaceAll("(?m)^[ \t]*\r?\n", "");

      FileOutputStream File = new FileOutputStream("../users/subs/" + loginCliente.clientelogado);
      File.write(input2.getBytes());
      file.close();
      File.close();

   } catch(Exception e) {
      System.out.println("Erro");
   }


     System.out.print("\033[H\033[2J");
     System.out.flush();
     ElimSubs();

}





// VERIFICAR PALAVRA-PASS -----------------------------------------------
public static void verificarPass() {

  Scanner stdin = new Scanner(System.in);

  String password;
  System.out.print("Digite a sua palavra passe atual: ");

  password = stdin.nextLine();

  verificarPass2(password);


}






// ALTERAR PALAVRA-PASS -------------------------------------------------
public static void alterarPass() {

  Scanner stdin = new Scanner(System.in);


  int cont=0; int j=3;


  try {
    BufferedReader bf = new BufferedReader(new FileReader("../users/users.txt"));
    StringBuilder str = new StringBuilder();
    String linha = bf.readLine();

      while(linha != null) {
        str.append(linha); // verificar todos os utilizadores
        str.append(System.lineSeparator()); // seperador de linha
        linha = bf.readLine();
        cont++;
      }



          // -------- Mudar a palavra passe ------------ //


            String user = loginCliente.clientelogado;

            String novaPass;
            System.out.print("Digite a nova palavra passe: "); novaPass = stdin.next();
            novaPass = " " + user + " " + novaPass + "\n";

            try
              {
              String lineToRemove = user;
              BufferedReader file = new BufferedReader(new FileReader("../users/users.txt"));
              String line;
              String input = "";
                while ((line = file.readLine()) != null){

                    if(line.contains(lineToRemove)) {
                        line = "";
                    }
                    input += line + '\n';
                }
                String input2 = input.replaceAll("(?m)^[ \t]*\r?\n", novaPass);

                FileOutputStream File = new FileOutputStream("../users/users.txt");
                File.write(input2.getBytes());
                file.close();
                File.close();
          // -----------------------------------------
          }
          catch(Exception e)
          {
            System.out.println("Temos um Erro kk");
          }


          // Sleep
          try {
        System.out.println("Palavra passe alterada com sucesso!");
          Thread.sleep(700);
        } catch (Exception e) {
          System.out.print("Erro kkk!");
        }

        // atualizar este metodo
        System.out.print("\033[H\033[2J");
        System.out.flush();
        menu(); // Voltar ao menu Admin */

  } catch (Exception e) {
    System.out.print("Erro kkk!");
  }




}






// VERIFICAR PASS -------------------------------------------------------
public static void verificarPass2(String pass) {

    Scanner stdin = new Scanner(System.in);

    String user = loginCliente.clientelogado;

    pass = pass + "\n"; // dar espaço à pass para conseguir comparar


    // Leitura dos dados dos Utilizadores (https://www.youtube.com/watch?v=knTjw-vV_VI)
    int cont=0; int j=1; int k=2;
    int a = 0; // aceder à pass na string
    int bool=2; int boolPass=2; // booleano para o username e a password
    try {
      BufferedReader bf = new BufferedReader(new FileReader("../users/users.txt"));
      BufferedReader separa = new BufferedReader(new FileReader("../users/users.txt"));
      StringBuilder str = new StringBuilder();
      String linha = bf.readLine();
      while(linha != null) {
        str.append(linha); // verificar todos os utilizadores
        str.append(System.lineSeparator()); // seperador de linha
        linha = bf.readLine();
        cont++;
      }

      String dados = str.toString();
      String[] separar = dados.split(" "); // separar os users e passwords
      // Verificar se existe o Username
      for(int t=0; t<cont; t++) {
        if(user.equals(separar[j])) { // Existe esse Username?
          bool = 1;
          a=j;
          break;
        }else { // Não existe esse Username
          bool = 0;
        }
        j=j+2;
      }
      // Verificar se existe a Password
      if(bool == 1){
        if(pass.equals(separar[a+1])) {
          boolPass = 1;
        }
      }

    } catch (Exception e) {
      System.out.print("Erro kkk!");
    }


    int escolha = 0;

    // Passowrd não aceite
    if((bool == 0) || (boolPass != 1)) {
    System.out.println("Atenção! :: Palavra passe errada!");

    System.out.print("1. Tentar novamente \n2. Voltar atrás\nEscolha: ");
    escolha = stdin.nextInt();

    // Escolha errada
    while(escolha > 2 || escolha <= 0) {
      System.out.print("Escolha errada, tente novamente: ");
      escolha = stdin.nextInt();
      }

      if(escolha == 1) {
      System.out.print("\033[H\033[2J");
      System.out.flush();
      verificarPass();
    }

      if(escolha == 2) {
        System.out.print("\033[H\033[2J");
        System.out.flush();
        menu();
      }

  }


    // Passsword aceite
    if((bool == 1) && (boolPass == 1))

    alterarPass();

  }






// TOPICOS ATIVOS -------------------------------------------------------
public static void topicosactivos() {

  Scanner stdin = new Scanner(System.in);

  System.out.println("* TÓPICOS (comentários) *"  );
  System.out.println();

  //guardar nomes dos topicos no array parentdir
  File parentfile = new File("../topicos");
  String[] parentdir = parentfile.list(new FilenameFilter() {
    @Override
    public boolean accept(File current, String name) {
      return new File(current, name).isDirectory();
    }
  });

  //criar array numcomment que contem o numero de comentarios
  //de cada topico
  int[] numcomment = new int[parentdir.length];

  //preencher o array nuncomment
  for(int i=0; i<parentdir.length; i++){
    //preencher o array comment com o nome dos comentarios
    File file = new File("../topicos/" + parentdir[i]);
    String[] comment = file.list(new FilenameFilter() {
      @Override
      public boolean accept(File current, String name) {
        return new File(current, name).isFile();
      }
    });

    //guardar o numero de comentarios de cada topico
    //no array numcomment
    int numdirs = comment.length;
    numcomment[i] = numdirs-1;
  }



    for(int i=0; i<parentdir.length; i++){
        System.out.println("- Tópico *" +parentdir[i] + "*  (" + numcomment[i] + " comentários)");
  }


  System.out.println();
  System.out.println("0. Voltar atrás");

  System.out.print("Escolha uma opção: ");

  int escolha = stdin.nextInt();

  // Escolha errada
  while(escolha != 0) {
    System.out.print("Escolha errada, tente novamente: ");
    escolha = stdin.nextInt();

  }

  if(escolha == 0){
    System.out.print("\033[H\033[2J");
    System.out.flush();
    menu();
  }


}






// ESTATISTICAS ---------------------------------------------------------
public static void estatisticas(){

  Scanner stdin = new Scanner(System.in);

    System.out.println("* ESTATÍSTICAS *");

    System.out.println("1. Tópicos que contêm comentários");
    System.out.println("2. Quantidade de mensagens de um determinado tópico");
    System.out.println("3. Número de utilizadores que interagiram num respectivo tópico");
    System.out.println("4. Quantidade de likes por tópico");

    System.out.println("\n0. Voltar atrás");

    System.out.print("Escolha uma opção: "); int num = stdin.nextInt();


    while(num < 0 || num > 4) {
      System.out.print("Escolha errada, tente novamente: ");
      num = stdin.nextInt();
    }

    if(num == 0) {
      System.out.print("\033[H\033[2J");
      System.out.flush();
      menu();
    }

    switch (num) {
       case 1: System.out.print("\033[H\033[2J");
               System.out.flush();
               topicoscomments();
               break;
       case 2: System.out.print("\033[H\033[2J");
               System.out.flush();
               topicosactivos();
               break;
       case 3: System.out.print("\033[H\033[2J");
               System.out.flush();
               quantidadeusers();
               break;
       case 4: System.out.print("\033[H\033[2J");
               System.out.flush();
               quantidadeLikes();
               break;





              }
  }

  public static void topicoscomments() {


        Scanner stdin = new Scanner(System.in);

        System.out.println("* TÓPICOS ATIVOS *");

        //guardar nomes dos topicos no array parentdir
        File parentfile = new File("../topicos");
        String[] parentdir = parentfile.list(new FilenameFilter() {
          @Override
          public boolean accept(File current, String name) {
            return new File(current, name).isDirectory();
          }
        });


        //preencher o array nuncomment
        for(int i=0; i<parentdir.length; i++){
          //preencher o array comment com o nome dos comentarios
          File file = new File("../topicos/" + parentdir[i]);
          String[] comment = file.list(new FilenameFilter() {
            @Override
            public boolean accept(File current, String name) {
              return new File(current, name).isFile();
            }
          });

        }



        System.out.println("Existem " + parentdir.length + " tópicos ativos:");



          for(int i=0; i<parentdir.length; i++) {
            System.out.println("- " + parentdir[i]);
          }

          System.out.println();
          System.out.println("0. Voltar atrás");

          System.out.print("Escolha uma opção: ");

          int escolha = stdin.nextInt();

          // Escolha errada
          while(escolha != 0) {
            System.out.print("Escolha errada, tente novamente: ");
            escolha = stdin.nextInt();

          }

          if(escolha == 0){
            System.out.print("\033[H\033[2J");
            System.out.flush();
            estatisticas();
          }


        }


  public static void quantidadeusers() {

            Scanner stdin = new Scanner(System.in);

            System.out.println("* NÚMERO DE UTILIZADORES QUE INTERAGIRAM NUM TÓPICO *");

            //guardar nomes dos topicos no array parentdir
            File parentfile = new File("../topicos");
            String[] parentdir = parentfile.list(new FilenameFilter() {
              @Override
              public boolean accept(File current, String name) {
                return new File(current, name).isDirectory();
              }
            });

            //criar array numcomment que contem o numero de comentarios
            //de cada topico
            int[] numcomment = new int[parentdir.length];

            //preencher o array nuncomment
            for(int i=0; i<parentdir.length; i++){
              //preencher o array comment com o nome dos comentarios
              File file = new File("../topicos/" + parentdir[i]);
              String[] comment = file.list(new FilenameFilter() {
                @Override
                public boolean accept(File current, String name) {
                  return new File(current, name).isFile();
                }
              });

              //guardar o numero de comentarios de cada topico
              //no array numcomment
              int numdirs = comment.length;
              numcomment[i] = numdirs-1;
            }

              int b=1;
              // Todos os topicos e o nº dos seus comentários
                for(int i=0; i<parentdir.length; i++){
                    System.out.println(b + ". " + parentdir[i]);
                    b++;
                  }



                System.out.println();
                System.out.println("0. Voltar atrás");

                System.out.print("Escolha uma opção: ");

                int escolha = stdin.nextInt();

                int cont = 0;

                if(escolha > 0 && escolha < b) {
                try {
                  BufferedReader bf = new BufferedReader(new FileReader("../topicos/" + parentdir[escolha-1] + "/likes/xusers"));

                  StringBuilder str = new StringBuilder();
                  String linha = bf.readLine();

                  while(linha != null) {
                    str.append(linha); // verificar todos os utilizadores
                    str.append(System.lineSeparator()); // seperador de linha
                    linha = bf.readLine();
                    cont++;
                  }

                  System.out.println("\nNo tópico *" + parentdir[escolha-1] + "* interagiram " + cont + " utilizador(s) diferente(s)\n");


                } catch (Exception e) { // verificar os erros
                  System.out.println("Erro kkk!");
                }
                    }




            // Escolha errada
            while(escolha < 0 || escolha >= b) {
              System.out.print("Escolha errada, tente novamente: ");
              escolha = stdin.nextInt();
            }

            if(escolha == 0){
              System.out.print("\033[H\033[2J");
              System.out.flush();
              estatisticas();
            }


            System.out.println("Deseja ver mais?");
            System.out.println(b + ".Sim  " + (b+1) + ".Não");
            System.out.print("Escolha uma opção: ");

            int choice = stdin.nextInt();

            if(choice == b) {
              System.out.print("\033[H\033[2J");
              System.out.flush();
              quantidadeusers();
            }

            if(choice == b+1) {
              System.out.print("\033[H\033[2J");
              System.out.flush();
              estatisticas();

            }

          }



// QUANTIDADE DE LIKES
public static void quantidadeLikes() {

  Scanner stdin = new Scanner(System.in);

  System.out.println("* QUANTIDADE DE LIKES POR TÓPICO *");

  //nome das folders colocados em directories
  File file = new File("../topicos");
  String[] directories = file.list(new FilenameFilter() {
    @Override
    public boolean accept(File current, String name) {
      return new File(current, name).isDirectory();
    }
  });

  int c=1;
  //numerar folders a partir de directories[]
  int numdirs = directories.length;
  for(int i=0; i<numdirs; i++){
    System.out.println(c + ". " + directories[i]);
    c++;
  }

System.out.println("\n 0. Voltar atrás");

System.out.print("Escolha uma opção: ");
  int choice = stdin.nextInt();


  while(choice < 0 || choice >=c) {
    System.out.println("Escolha errada, tente novamente: ");
    choice = stdin.nextInt();
  }


  if(choice == 0) {
    System.out.print("\033[H\033[2J");
    System.out.flush();
    estatisticas();
  }


  // "LER" OS LIKES
  int j=1; int cont=0; int soma=0;
  try {
    BufferedReader bf = new BufferedReader(new FileReader("../topicos/" + directories[choice-1] + "/likes/likes"));
    BufferedReader separa = new BufferedReader(new FileReader("../topicos/" + directories[choice-1] + "/likes/likes"));
    StringBuilder str = new StringBuilder();
    String linha = bf.readLine();

      while(linha != null) {
        str.append(linha); // verificar todos os utilizadores
        str.append(System.lineSeparator()); // seperador de linha
        linha = bf.readLine();
        cont++;
      }

      String dados = str.toString();
      String[] separar = dados.split(" "); // separar os users e passwords


      String lk;
      int k=2;

      for(int i=0; i<cont; i++) {
        lk = separar[k];
        soma = soma + Integer.parseInt(lk);
        k += 3;
      }

      System.out.println("\nO tópico " + directories[choice-1] + " tem " + soma + " likes");


} catch (Exception e) {
  System.out.print("Erro kkk!");
}


System.out.println("\nDeseja ver mais?");
System.out.println("1.Sim  2.Voltar atrás");
System.out.println("Escolha uma opção: ");

int choice2 = stdin.nextInt();

while(choice2!=1 && choice2!=2) {
  System.out.println("Escolha errada, tente novamente: ");
  choice = stdin.nextInt();
}


if(choice2 == 1) {
  System.out.print("\033[H\033[2J");
  System.out.flush();
  quantidadeLikes();
}
if(choice2 == 2) {
  System.out.print("\033[H\033[2J");
  System.out.flush();
  estatisticas();
}

}





}
