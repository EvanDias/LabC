import java.util.Scanner;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.*;

// ------------------------------------
public class loginServer {

  public static void main(String[] Args) {
    menuLoginServer();
}


// MENU LOGIN --------------------------------------------------------------------------------
public static void menuLoginServer() {

    System.out.print("\033[H\033[2J");
    System.out.flush();

Scanner stdin = new Scanner(System.in);

System.out.println("*ADMIN AUTENTICATION*");
System.out.println("1. Login");
System.out.println("2. Sair");
System.out.print("Escolha uma opção: ");

int num = stdin.nextInt();

// Escolha dos numeros
switch (num) {
    case 1: System.out.print("\033[H\033[2J");
            System.out.flush();
            loginServerAutentication();
                break;
    case 2: System.exit(0);
    default: while(num!=1 && num!=2) { // Numero invalido
                System.out.print("Escolha errada, tente novamente: ");
                num = stdin.nextInt();
             }
}
  }



  // Guardar o usarname do admin
  public static String userlogado;




// LOGIN USER ------------------------------------------------------------------
  public static void loginServerAutentication() {
  Scanner stdin = new Scanner(System.in);

  // Login Menu (username && Password)
  String user, pass;
  System.out.print("Username: ");  // Username
  user = stdin.nextLine();
  System.out.print("Password: "); // Password
  pass = stdin.nextLine();
  pass = pass + "\n"; // dar espaço à pass para conseguir comparar


  // Leitura dos dados dos Utilizadores (https://www.youtube.com/watch?v=knTjw-vV_VI)
  int cont=0; int j=1; int k=2;
  int a = 0; // aceder à pass na string
  int bool=2; int boolPass=2; // booleano para o username e a password

    try {
      BufferedReader bf = new BufferedReader(new FileReader("../users/usersServer.txt"));
      BufferedReader separa = new BufferedReader(new FileReader("../users/usersServer.txt"));
      StringBuilder str = new StringBuilder();

      String linha = bf.readLine();

      while(linha != null) {
        str.append(linha); // verificar todos os utilizadores
        str.append(System.lineSeparator()); // seperador de linha
        linha = bf.readLine();
        cont++;
      }

      String dados = str.toString();
      String[] separar = dados.split(" "); // separar os users e passwords

      // Verificar se existe o Username
      for(int t=0; t<cont; t++) {
        if(user.equals(separar[j])) { // Existe esse Username?
          bool = 1;
          a=j;
          break;
        } else { // Não existe esse Username
          bool = 0;
          j=j+2;
        }

    // Verificar se existe a Password
    }
      if(bool == 1){
      if(pass.equals(separar[a+1])) {
        boolPass = 1;
      }
    }

    } catch (Exception e) {
      System.out.print("Erro kkk!");
    }

  int escolha=0;
  // Username ou Passowrd não aceites
    if((bool == 0) || (boolPass != 1)) {
      System.out.println("Atenção! :: Utlizador ou palavra passe incorretos.\n");

  System.out.print("1. Tentar novamente \n2. Voltar atrás\nEscolha: ");
  escolha = stdin.nextInt();

  // Escolha errada
  while(escolha > 2 || escolha <= 0) {
    System.out.print("Escolha errada, tente novamente: ");
    escolha = stdin.nextInt();
    }

    if(escolha == 1) {
    System.out.print("\033[H\033[2J");
    System.out.flush();
    loginServerAutentication();
  }

    if(escolha == 2) {
      System.out.print("\033[H\033[2J");
      System.out.flush();
      menuLoginServer();
    }
  }


  // Username e Passsword aceites
    if((bool == 1) && (boolPass == 1)) {
      userlogado = user;
      System.out.println("Successful Logged!");
      System.out.print("\033[H\033[2J");
      System.out.flush();

      menuServer texto = new menuServer(); //CHAMAR METODO MENUADMIN NO MENUSERVER
      texto.menuAdmin();
  }

    }


  }
